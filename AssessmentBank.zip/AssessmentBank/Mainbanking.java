//Program To Find The Balance,Withdraw,Deposit,Closing(for Basic,Standard,Premiuim,Joint Account)
/*In This Program I Have Used Pojo Method(Class Should Be In Public,Class Properties should be in private,
*Getters And Setters Must Be Included,Default Constructors Must Be Used).
*Not to do in pojo (should not extend predefined classes(scanner,array etc.,) ,not implements predefined interfaces ,should not have annotations.*/
//Multi-Level Inheritance ,UserDefined Exception Handling ANd System Defined Exception Handling Are Used.
//ArrayList Is Used For Storing Particular Withdraw,Deposit Details.
//HashMap Is Used For Storing the Customer Data 

package AssessmentBank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;

import java.util.Scanner;

import java.util.concurrent.ThreadLocalRandom;

import AssessmentBank.JointAccount.joint_account;
import AssessmentShapes.Learners_Login;

public class Mainbanking {
	static Scanner input = new Scanner(System.in);
	static HashMap<Long, String> accountDetails = new HashMap<Long, String>();
	static HashMap<String, String> accountType = new HashMap<String, String>();
	static BasicAccount basicAccount = new BasicAccount();
	static StandardAccount standardAccount = new StandardAccount();
	static PremiumAccount premiumAccount = new PremiumAccount();
	static JointAccount.joint_account jointAccount1 = new JointAccount().new joint_account();
private static final String QUERY = "select AccountNumber,Name,AccountType from bankcustomers where AccountNumber =? And Name =?";
	
	private static final String INSERT_bankcustomers_SQL = "INSERT INTO bankcustomers" +
	        "  (AccountNumber,Name, AccountType, Date) VALUES " +
	        " (?, ?, ?,?);"
	         ;

	public static void main(String[] args) throws Exception {
       
		
		System.out.println("<<<<<We Welcome You to IEIEI Bank>>>>>");
		System.out.println("For the Customer of the Customers And by the Customers");
		System.out.println("Address: No:231,MKN Road,Alandur,Chennai-600018");
		System.out.println("");
		Thread.sleep(2000);
     	

		basicAccount.setTotalBalance(100000.00);
		standardAccount.setTotalBalance(100000.00);
		premiumAccount.setTotalBalance(1000000.00);
		try {
			System.out.println("Are you an existing customer or to open a new Account or else just visiting our bank");
			System.out.println("Select the option 1 if you are Existing customer");
			System.out.println("Select the option 2 if you are new customer");
			System.out.println("Select the option 3 if you came to just visit");

			int value = input.nextInt();
			if (value == 1) {
				existingCustomer();
			}

			else if (value == 2) {
				newCustomer();
			} else if (value == 3) {
				System.out.println(
						"The Basic Savings Bank Account  is a Savings Account that does not have a Minimum balance Limit");
				System.out.println(
						"The Standard savings Bank Account is specially used to deposit certain amount and earn insterest, ");
				System.out.println(
						"Premium savings accounts are specialised savings accounts that offer improved and enhanced banking features and customised services.");
				System.out.println("A joint account is a bank account that has been opened by two individuals .");
				System.out.println("Do You Wish To Open account in our bank enter 1");
				System.out.println("Else enter 2");
				int answer = input.nextInt();
				if (answer == 1) {
					newCustomer();
				}
				if (answer == 2) {
					System.out.println("Thank you for visting our Bank , The IEIEI BANK always Welcomes you");
				}
			} else {
				System.out.println("You have entered an invalid option");
			}
		} catch (Exception e) {
			System.out.println("Please enter the correct type");

		}}
	

	static void existingCustomer() throws Exception {
		System.out.println("Hi Customer");
		System.out.println("Please enter your details to fetch");
		System.out.println("Enter your IEIEI bank Account number");
		int account_Number = input.nextInt();
		System.out.println("Please Enter your name");
		String accountHolderName = input.next();
		System.out.println("Enter Your Account Type");
		String AccountType = input.next();

		try (Connection connection = DriverManager
	            .getConnection("jdbc:mysql://localhost:3306/bankmanagement?", "root", "infotel");

	            // Step 2:Create a statement using connection object
	            PreparedStatement preparedStatement = connection.prepareStatement(QUERY);) {
	            preparedStatement.setInt(1,account_Number);
	            preparedStatement.setString(2,accountHolderName);
	           
	            System.out.println(preparedStatement);
	            // Step 3: Execute the query or update query
	            ResultSet rs = preparedStatement.executeQuery();

	            // Step 4: Process the ResultSet object.
	            while (rs.next()) {
	            	String number = rs.getString("AccountNumber");
	                String name = rs.getString("Name");
	                String type = rs.getString("AccountType");
	          System.out.println("Hi ! : "+accountHolderName);
	             System.out.println("Your Account Number Is : "+number); 
	             System.out.println("Your Account Type Is : "+type);
	             switch (type) {
					case "Premium": {

						
						premiumAccount.show();
	break;
					}
					case "Basic": {
						basicAccount.show();
						break;
					}
					case "Standard": {
						standardAccount.show();
						break;
					}
					case "Joint": {
						
						jointAccount1.show();
						break;
					}

					}  	            
	            }
	        } catch (SQLException e) {
	        }
	        // Step 4: try-with-resource statement will auto close the connection.
	}

	static void newCustomer() throws SQLException {
		try {
			LocalDate date = LocalDate.now();
			String Date = date.toString();
			System.out.println(
					"The Basic Savings Bank Account  is a Savings Account that does not have a Minimum balance Limit");
			System.out.println(
					"The Standard savings Bank Account is specially used to deposit certain amount and earn insterest, ");
			System.out.println(
					"Premium savings accounts are specialised savings accounts that offer improved and enhanced banking features and customised services.");
			System.out.println("A joint account is a bank account that has been opened by two individuals .");
			System.out.println("Enter your Details ");
			System.out.println("Choose your Account type Basic,Standard,Premium,Joint Account ");
			String accounTType = input.next();
			System.out.println("Enter Your Name:");
			String accountHolder = input.next();

			System.out.println("Enter Your PhoneNumber");
			Long phoneNumber = input.nextLong();
			System.out.println("Please Check again the  details");
			System.out.println(" Your Account Type Is :" + accounTType);
			System.out.println(" Your Name  Is :" + accountHolder);

			System.out.println(" Your phoneNumber  Is :" + phoneNumber);
			System.out.println("Please Type Yes  The  Details are Correct");
			String answer = input.next();
			int AccountNumber1 = ThreadLocalRandom.current().nextInt();
			int AccountNumber = Math.abs(AccountNumber1);
			System.out.println("Your Account Number Is : " +AccountNumber );
			switch (answer) {
			case "Yes":{
//				Account_Details.put(b, account_holder_Name);
//				Account_Type.put(account_holder_Name, accountType);
				try (Connection connections = DriverManager
		        .getConnection("jdbc:mysql://localhost:3306/bankmanagement?", "root", "infotel");
						
		        // Step 2:Create a statement using connection object
		        PreparedStatement preparedStatements = connections.prepareStatement(INSERT_bankcustomers_SQL)) {			
		 preparedStatements.setInt(1, AccountNumber);
	   preparedStatements.setString(2,accountHolder);
	  preparedStatements.setString(3, accounTType);
	  preparedStatements.setString(4, Date);
	  preparedStatements.executeUpdate();    	
	  connections.close();

	}
	  catch (SQLException e) {
	    	 printtheSQLException(e);

	        // print SQL exception information
	  }
	 finally {
		 
	 }	
			
				break;
			}
			default:	
				System.out.println("Please Visit Again  ");
			}
			}
			catch(Exception e) {
				System.out.println("Please Enter The Correct Match ,You Have entered input That Does'nt Match");
				
			}
	}
	public static void printtheSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                System.out.println("Entered Name Is Not In Our List");
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
}

	}