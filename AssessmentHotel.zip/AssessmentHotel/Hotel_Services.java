package AssessmentHotel;

public class Hotel_Services  extends Main_Hotel{
	

	void services() throws InterruptedException {
		System.out.println("HOTEL MAYIL was Founded by MR.MAYIL UDAIYAR B.E,  in the  year 2010 till now this is one of the best Serving hotel .");
		Thread.sleep(1000);
		System.out.println("Our Hotel Rooms Are Specially for single person");
		Thread.sleep(1000);
		System.out.println("Our Hotel is fully sanitized and we will clean room the twice a day");
		Thread.sleep(1000);
		System.out.println("Our Hotel contains a number of 10 rooms");
		Thread.sleep(1000);
		System.out.println("If you want to Continue for booking process (Enter 1)or(Enter 2 -for exit)");
		System.out.println("**************************************************************************************");

			}



}