package Application_Mayil;

public class LevelTwoFormulas {
	final static double PI = 3.14159;

	public void finalize() {
		System.out.println("Do You Want To  Exit ,if Exit Means Enter 1");
	}

//Inner Class	

	private int radius, length, width;
	private float height;
	private int base;
	private double area;
	private double side;
	private double circumference;

//		public int getRadius( int radius) {
//			return radius;
//		}
//		public void setRadius(int radius) {
//			this.radius = radius;
//		}

	public float getHeight(float height) {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public int getBase(int base) {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	public int getLength(int length) {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth(int width) {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public float getSide(float side) {
		return side;
	}

	public void setSide(float side) {
		this.side = side;
	}

	// Method Overloading Used For Common Methods Such AS Area And Circumference By
	// Passing Different Arguments
	// Method For Area of Circle
	void area(int radius) {
		area = Math.PI * radius * radius;
		System.out.println("Area of Circle : " + (int) area);
	}

	void area(double radius, double height) {
		System.out.println("Area Of cylinder : 2 *PI* radius * height+2*PI*(radius*radius)");
		area = 2 * PI * radius * height + 2 * PI * (radius * radius);
		System.out.println("Area of Cylinder : " + (double) area);
	}

	void area(double radius, int length) {
		System.out.println("Area Of cone : PI  * radius * (radius + length);");
		area = PI * radius * (radius + length);
		System.out.println("Area of cone:" + (double) area);
	}

	void area(float side) {
		System.out.println("Area Of cube : 6  *( side * side);");
		area = 6 * (side * side);
		System.out.println("Area of cube:" + (double) area);
	}

	// Method For Area of Triangle
	void area(float height, int base) {
		System.out.println("Area of Triangle:(Height*Base)/2");
		area = (height * base) / 2;
		System.out.println("Area of Triangle : " + (int) area);
	}

	// Method For Area of Rectangle
	void area(int length, int width) {
		System.out.println("Area of Rectangle:Length*Width");
		area = length * width;
		System.out.println("Area of Rectangle : " + (int) area);

	}

	// Method For Circumference of Circle
	void circumference(int radius) {
		System.out.println("Circumference of Circle:2*pi*radius");
		circumference = 2 * PI * radius;
		System.out.println("Circumference of Circle:" + (int) circumference);
	}

	// Method For Circumference of Triangle
	void circumference(float side, int base) {
		System.out.println("Circumference of Triangle:side+Base+Base");
		circumference = side + base + side;
		System.out.println("Circumference of Triangle:" + (int) circumference);

	}

	// Method For Circumference of Rectangle
	void circumference(int length, int width) {
		System.out.println("Circumference of Rectangle:2*Length+2*Width");
		circumference = 2 * length + 2 * width;
		System.out.println("Circumference of Triangle:" + (int) circumference);
	}

	void circumference(double radius, double height) {
		System.out.println("Circumference Of cylinder : 2*PI*radius");
		circumference = 2 * PI * radius;
		System.out.println("Circumference of cylinder :" + (double) circumference);
	}

	void circumference(double radius) {
		System.out.println("Circumference Of Cone : 2*PI*radius");
		circumference = 2 * PI * radius;
		System.out.println("Circumference of Cone :" + (double) circumference);
	}

	void circumference(float side) {
		System.out.println("Circumference Of Cube : 12*side");
		circumference = 12 * side;
		System.out.println("Area of cube:" + (float) area);
	}

}
