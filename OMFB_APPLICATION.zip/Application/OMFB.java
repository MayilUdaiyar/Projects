package Application_Mayil;

import java.util.Scanner;



public class OMFB extends Thread {

//Constructor Class	Is Used For Welcome Note	
	OMFB() {

		System.out.println("********************************************************************************************************************** ");

		System.out.println("<<<<Hi Learners>>>> ");
		System.out.println("<<<<Welcome to the Online Mathematical Formula Box(OMFB)>>>>");

		System.out.println("********************************************************************************************************************** ");


		
	}

// Enumeration Is Used For Exit Option Note
	private enum Enum {
		Bye("You have been exited");

		public String label;

		private Enum(String label) {
			this.label = label;
		}

	}

	public void finalize() {
		System.out.println("Do You Want To  Exit ,if Exit Means Enter 1");
	}

	final static float PI = 3.14f;
	private static final String C = null;

	public static void main(String[] args) {
		LevelTwoFormulas objectF2 = new LevelTwoFormulas();
		LevelThreeFormulas objectF3 = new LevelThreeFormulas();
		QuadraticEquation objectF4=new QuadraticEquation();
		OMFB object2 = new OMFB();
		UserLogin objectUser= new UserLogin();
		objectUser.UserLogin();
		System.out.println("<<<THANK YOU for your Patience>>>");
		System.out.println("....Now you can LEARN Mathematical formulas....");
		System.out.println("* If you are Beginer Please select the Level 1 formulas  ");
		System.out.println("* If you are Intermediate Please select the Level 2 formulas ");
		System.out.println("* If you are Expert Please select the Level 3 formulas");
		System.out.println("********************************************************************************************************************** ");

		System.out.println("Note: You can  able to understand the formulas By studying in order of Levels");
		System.out.println("********************************************************************************************************************** ");

		System.out.println("Select the Level of formula...");
		System.out.println("Enter A For Level 1 formulas: ");
		System.out.println("Enter B For Level 2 formulas: ");
		System.out.println("Enter C For Level 3 formulas: ");
		System.out.println("********************************************************************************************************************** ");

		Scanner scan = new Scanner(System.in);

		while (true) {
			try {

				String alph1 = scan.next();
				switch (alph1) {

				case "A":
					System.out.println("You have selected Level 1 formulas");
					System.out.println("Enter 1 for addition");
					System.out.println("Enter 2 for subtraction");
					System.out.println("Enter 3 for Division");
					System.out.println("Enter 4 for Multiplication");
					System.out.println("Enter 5 for Module");

					int num123 = scan.nextInt();
					if (num123 == 1) {
						System.out.println("Enter the first Value");
						double addition = scan.nextDouble();
						System.out.println("Enter the Second Value");

						System.out.println("THE FORMULA IS: first Value + Second Value ");
						double addition2 = scan.nextDouble();
						double result = addition + addition2;
						System.out.println("Calculating the Values");
						Thread.sleep(1000);
						System.out.println("The answer is =" + result);
						object2 = null;
						System.gc();
						int getoption = scan.nextInt();
						if (getoption == 1) {
							System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
							Thread.sleep(1000);
							System.out.println(Enum.Bye.label);
							break;
						}
					}

					if (num123 == 2) {
						System.out.println("Enter the first Value");
						double subtraction = scan.nextDouble();
						System.out.println("Enter the Second Value");
						double subtraction2 = scan.nextDouble();
						System.out.println("THE FORMULA IS: firstvalue - second value");
						double result2 = subtraction - subtraction2;
						System.out.println("Calculating the Values");
						Thread.sleep(1000);
						System.out.println("The answer is =" + result2);
						object2 = null;
						System.gc();
						int getoption = scan.nextInt();
						if (getoption == 1) {
							System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
							Thread.sleep(1000);
							System.out.println(Enum.Bye.label);
							break;
						}
					}

					if (num123 == 3) {
						System.out.println("Enter the first Value");
						double division = scan.nextDouble();
						System.out.println("Enter the Second Value");
						double division2 = scan.nextDouble();
						System.out.println("THE FORMULA IS: firstvalue / second value");
						double result3 = division / division2;
						System.out.println("Calculating the Values");
						Thread.sleep(1000);
						System.out.println("The answer is =" + result3);
						object2 = null;
						System.gc();
						int getoption = scan.nextInt();
						if (getoption == 1) {
							System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
							Thread.sleep(1000);
							System.out.println(Enum.Bye.label);
							break;
						}
					}
					if (num123 == 4) {
						System.out.println("Enter the first Value");
						double multiplication = scan.nextDouble();
						System.out.println("Enter the Second Value");
						double multiplication2 = scan.nextDouble();
						System.out.println("THE FORMULA IS: firstvalue * second value");
						double result4 = multiplication * multiplication2;
						System.out.println("Calculating the Values");
						Thread.sleep(1000);
						System.out.println("The answer is =" + result4);
						object2 = null;
						System.gc();
						int getoption = scan.nextInt();
						if (getoption == 1) {
							System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
							Thread.sleep(1000);
							System.out.println(Enum.Bye.label);
							break;
						}

					}
					if (num123 == 5) {
						System.out.println("Enter the first Value");
						double percentage = scan.nextDouble();
						System.out.println("Enter the Second Value");
						double percentage2 = scan.nextDouble();
						System.out.println("THE FORMULA IS: firstvalue % second value");
						double result5 = percentage % percentage2;
						System.out.println("Calculating the Values");
						Thread.sleep(1000);
						System.out.println("The answer is =" + result5);
						object2 = null;
						System.gc();
						int getoption = scan.nextInt();
						if (getoption == 1) {
							System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
							Thread.sleep(1000);
							System.out.println(Enum.Bye.label);
							break;
						}

					}

				case "B":

					System.out.println("You Have Selected Level 2 Formulas ");
					System.out.println("Finding The Area of Shapes!!!!");
					System.out.println("Enter 1 For Circle Shape :");
					System.out.println("Enter 2 For Triangle Shape :");
					System.out.println("Enter 3 For Rectangle Shape:");
					int number = scan.nextInt();

					if (number == 1) {
						System.out.println("Bringing you the  option you selected");
						// Thread sleep is used here to wait for 1000 milliseconds
						Thread.sleep(1000);
						// After 1000 milliseconds have elapsed, control returns
						System.out.println(" Here i have 2 more options for you  ");
						System.out.println(" Press 1 for for Area of Circle and  Circumference of the Circle");
						System.out.println(" Press 2 for for Area of Circle and  Circumference of the Cylinder");

						int optionArea = scan.nextInt();

						if (optionArea == 1) {
							System.out.println("Press 1 for for Area of Circle ");
							System.out.println("Press 2 for Circumference of the Circle");

							int areaCirum = scan.nextInt();
							if (areaCirum == 1) {

								System.out.println("You Have Selected To Find The Area Of Circle");
								System.out.println("Enter The Radius:");
								int radius = scan.nextInt();
								System.out.println("Formula to Find Area of Circle:pi*radius*radius");
								objectF2.area(radius);
							} else if (areaCirum == 2) {
								System.out.println("You Have Selected To Find The Circumference Of Circle");
								System.out.println("THE FORMULA IS: 2 * PI * getradius");
								System.out.println("Enter The Radius:");
								int getradius = scan.nextInt();
								objectF2.circumference(getradius);
								object2 = null;
								System.gc();
							}
						} else if (optionArea == 2) {
							System.out.println("Press 1 for for Area of Cylinder ");
							System.out.println("Press 2 for Circumference of the Cylinder");
							int areaCircum = scan.nextInt();
							if (areaCircum == 1) {
								System.out.println("You Have Selected To Find The Area Of Cylinder");
								System.out.println("Enter The Radius:");
								System.out.println("Area Of cylinder : 2 *PI* radius * height+2*PI*(radius*radius)");
								double radius = scan.nextDouble();
								double height = scan.nextDouble();
								objectF2.area(optionArea);
								object2 = null;
								System.gc();
							} else if (areaCircum == 2) {

								System.out.println("You Have Selected To Find The Circumference Of Cylinder");
								System.out.println("THE FORMULA IS:2*PI*radius");
								System.out.println("Enter The Radius:");
								int getradius = scan.nextInt();
								objectF2.circumference(getradius);
								object2 = null;
								System.gc();
							}
						}
					}

					else if (number == 2) {
						System.out.println("Searching Your Choices...........");
						Thread.sleep(1000);
						System.out.println("You Have Selected To Find The Area  and Circumference of Triangle ");
						System.out.println("Do You want To Find The Area  and Circumference of Triangle enter 1");
						System.out.println("Additionally we included the formula for cone ");
						System.out.println("Do You want To Find The Area  and Circumference of CONE enter 2");

						int optionArea = scan.nextInt();

						if (optionArea == 1) {
							System.out.println(" Press 1 for for Area of Triangle ");
							System.out.println("Press 2 for Circumference of the Triangle");

							int areaCirum = scan.nextInt();
							if (areaCirum == 1) {

								System.out.println("You Have Selected To Find The Area Of Triangle");
								System.out.println("Enter The Height:");
								float height = scan.nextFloat();
								System.out.println("Enter The Base:");
								int base = scan.nextInt();
								System.out.println("Formula to Find Area of Triangle:(Height*Base)/2");
								objectF2.area(height, base);
							} else if (areaCirum == 2) {
								System.out.println("You Have Selected To Find The Circumference Of Triangle");
								System.out.println("THE FORMULA IS: side+Base+Base");
								System.out.println("Enter The Side:");
								float side = scan.nextFloat();
								System.out.println("Enter The Side:");
								int base = scan.nextInt();
								objectF2.circumference(side, base);
								object2 = null;
								System.gc();
							}
						} else if (optionArea == 2) {
							System.out.println("Press 1 for for Area of Cone ");
							System.out.println("Press 2 for Circumference of the Cone");
							int areaCirum = scan.nextInt();

							if (areaCirum == 1) {
								System.out.println("You Have Selected To Find The Area Of Cone");
								System.out.println("Enter The radius");
								System.out.println("Enter The height");
								double radius = scan.nextDouble();
								int length = scan.nextInt();
								objectF2.area(radius, length);
							}

							else if (areaCirum == 2) {
								System.out.println("You Have Selected To Find The Circumference Of Cone");
								System.out.println("THE FORMULA IS:2*PI*radius");
								System.out.println("Enter The Radius:");
								int getradius = scan.nextInt();
								objectF2.circumference(getradius);
								object2 = null;
								System.gc();
							}
						}
					}

					else if (number == 3) {
						System.out.println("Searching Your Choices...........");
						Thread.sleep(1000);
						System.out.println("You Have Selected To Find The Area  and Circumference of Rectangle ");
						System.out.println("Do You want To Find The Area  and Circumference of Rectangle enter 1");
						System.out.println("Additionally we included the formula for CUBE ");
						System.out.println("Do You want To Find The Area  and Circumference of Cube enter 2");

						int optionArea = scan.nextInt();

						if (optionArea == 1) {
							System.out.println(" Press 1 for for Area of Rectangle ");
							System.out.println("Press 2 for Circumference of the Rectangle");

							int areaCirum = scan.nextInt();
							if (areaCirum == 1) {

								System.out.println("Enter Length To Find Area And Circumference of Rectangle");
								System.out.println("[Note:Entered Length Should Be An Integer Value]");
								int length = scan.nextInt();
								System.out.println("Enter Width To Find Area And Circumference  of Rectangle ");
								System.out.println("[Note:Entered Width Should Be An Integer Value]");
								int width = scan.nextInt();
								System.out.println("Formula to Find Area of Rectangle:Length*Width");
								objectF2.area(length, width);
							} else if (areaCirum == 2) {
								System.out.println("You Have Selected To Find The Circumference Of Rectangle");
								System.out.println("THE FORMULA IS: 2*Length+2*Width");
								System.out.println("Enter The Length:");
								int length = scan.nextInt();
								System.out.println("Enter The Width:");
								int width = scan.nextInt();
								objectF2.circumference(length, width);
								object2 = null;
								System.gc();
							}
						} else if (optionArea == 2) {
							System.out.println("Press 1 for for Area of Cube ");
							System.out.println("Press 2 for Circumference of the Cube");
							int areaCirum = scan.nextInt();

							if (areaCirum == 1) {
								System.out.println("You Have Selected To Find The Area Of Cube");
								System.out.println("formula for Area Of cube : 6  *( side * side);");
								System.out.println("Enter The Side");
								float side = scan.nextFloat();
								objectF2.area(side);
							}

							else if (areaCirum == 2) {
								System.out.println("You Have Selected To Find The Circumference Of Cube");
								System.out.println("THE FORMULA IS:12*side");
								System.out.println("Enter The Side:");
								float side = scan.nextFloat();
								objectF2.circumference(side);
								object2 = null;
								System.gc();
							}
						}
					}

				case "C":
					System.out.println("The basi formulas in trignometry are given below ");
					System.out.println("sin θ = Opposite Side/Hypotenuse\r\n" + "cos θ = Adjacent Side/Hypotenuse\r\n"
							+ "tan θ = Opposite Side/Adjacent Side\r\n" + "sec θ = Hypotenuse/Adjacent Side\r\n"
							+ "cosec θ = Hypotenuse/Opposite Side\r\n" + "cot θ = Adjacent Side/Opposite Side");
					System.out.println("********************************************************************************************************************** ");

					System.out.println("Enter 1 to Workout  the Trignometry Formulas ");
					System.out.println("********************************************************************************************************************** ");

					System.out.println("Here I have additonally added the quadratic Equation");
					System.out.println("If you are interested in learning Enter 2 to learn ");
					System.out.println("********************************************************************************************************************** ");
					System.out.println("********************************************************************************************************************** ");
					int optionTri = scan.nextInt();

					if (optionTri == 1) {
						objectF3.Trignometry();
						object2 = null;
						System.gc();
						break;
					
					}
                 else if(optionTri==2) {
						
						objectF4.Quadratic();
					}
				default :
					System.out.println("Enter the correct input type");
			break;
				}
			} catch (Exception e) {
				System.out.println(e);
				System.out.println("Entered input is not an integer");
			}
		}
	}
}
