package Application_Mayil;

import java.util.Scanner;


	public class LevelThreeFormulas {
	  	static Scanner scan = new Scanner(System.in);

		void Trignometry() {

				  
				  System.out.println("Welcome to the trigonometry calculation!");

				  //Prompt user for which trigonometry function
				  
				 System.out.println("Which  trigonometry function do you want to use? :"+"\n 1 Sin"+"\n 2 Cos"+"\n 3 Tan"+"\n 4 Sec"+"\n 5 Cosec"+"\n 6 cot");
			
				 int userChoice = scan.nextInt();

				  	switch(userChoice){
				      case 1: sin(); break;
				      case 2: cos(); break;
				      case 3: tan(); break;
				      case 4: sec(); break;
				      case 5: cosec(); break;
				      case 6: cot(); break;
				      default: System.out.println("Invalid Choice.\n You have entered invalid choice,\n Exiting now please comeback");
				  }
				  }
					
				 
				 

			public static void sin() {
				  System.out.println("Enter value of angle in degrees ");
				  System.out.println("Please enter any one of the below given degrees\nThe Degrees are 0,30,45,60,90,120,180,270,360");
		   		  double degrees = scan.nextDouble();
		   		  double sineOfAngle = Math.sin(degrees); 
		   		 System.out.println("The Sine of " + degrees + " degrees is : "
		   			    + sineOfAngle);
			}
			  
			private static void cos() {
				  System.out.println("Enter value of angle in degrees ");
				  System.out.println("Please enter any one of the below given degrees\nThe Degrees are 0,30,45,60,90,120,180,270,360");
		 		  double degrees = scan.nextDouble();
		 		  double cosOfAngle = Math.cos(degrees); 
		 		 System.out.println("The Sine of " + degrees + " degrees is : "
		 			    + cosOfAngle);
			}
			private static void tan() {
				  System.out.println("Enter value of angle in degrees ");
				  System.out.println("Please enter any one of the below given degrees\nThe Degrees are 0,30,45,60,90,120,180,270,360");
				  double degrees = scan.nextDouble();
				  double tanOfAngle = Math.tan(degrees); 
				 System.out.println("The Cosine of " + degrees + " degrees is : "
					    + tanOfAngle);
			}
			
			private static void cosec() {
				  System.out.println("Enter value of angle in degrees ");
				  System.out.println("Please enter any one of the below given degrees\nThe Degrees are 0,30,45,60,90,120,180,270,360");
				  double degrees = scan.nextDouble();
				  double secOfAngle = 1 / Math.sin(degrees); 
				 System.out.println("The Tangent of " + degrees + " degrees is : "
					    + secOfAngle);
			}
			private static void sec() {
				  System.out.println("Enter value of angle in degrees ");
				  System.out.println("Please enter any one of the below given degrees\nThe Degrees are 0,30,45,60,90,120,180,270,360");
				  double degrees = scan.nextDouble();
				  double cosecOfAngle = 1 / Math.cos(degrees); 
				 System.out.println("The Tangent of " + degrees + " degrees is : "
					    + cosecOfAngle);
			}
			private static void cot() {
				  System.out.println("Enter value of angle in degrees ");
				  System.out.println("Please enter any one of the below given degrees\nThe Degrees are 0,30,45,60,90,120,180,270,360");
				  double degrees = scan.nextDouble();
				  double cotOfAngle = 1 / Math.tan(degrees);

				 System.out.println("The Tangent of " + degrees + " degrees is : "
					    + cotOfAngle);
			}
	}
