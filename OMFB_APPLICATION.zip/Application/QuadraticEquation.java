package Application_Mayil;

import java.util.Scanner;

public class QuadraticEquation {
  	static Scanner scan = new Scanner(System.in);

     
	void Quadratic() {
		System.out.println("welcome to the Quadratic equation formulas");
		System.out.println("Please give the values");
		System.out.println("Enter the value of 'a'");
	  	double a=scan.nextDouble();
	  	System.out.println("Enter the value of 'b'");
	  	double b=scan.nextDouble();
	  	System.out.println("Enter the value of 'c'");
	  	double c=scan.nextDouble();
	    // value a, b, and c
	    double root1, root2;

	    // calculate the determinant (b2 - 4ac)
	    double determinant = b * b - 4 * a * c;
	    System.out.println("The formula to calculate the determinant is (b2 - 4ac)");
        System.out.println("The Determinant is "+determinant);
        System.out.println("If the determinant is greater than Zero it Executes  root1 = (-b + Math.sqrt(determinant)) / (2 * a);\r\n"
        		+ "	      root2 = (-b - Math.sqrt(determinant)) / (2 * a);\r\n"
        		+ "  ");
        System.out.println("If the Determinant is Equal to 0 It Executes \nroot1 = root2 = -b / (2 * a); ");
        System.out.println("If  the Determinant is complex number or Less than 0 it Executes \n real = -b / (2 * a); \n imaginary = Math.sqrt(-determinant) / (2 * a);");
	    // check if determinant is greater than 0
	    if (determinant > 0) {

	      // two real and distinct roots
	      root1 = (-b + Math.sqrt(determinant)) / (2 * a);
	      root2 = (-b - Math.sqrt(determinant)) / (2 * a);
          System.out.println("The Answer is ");
	      System.out.format("root1 = %.2f and root2 = %.2f", root1, root2);
	      
	    }

	    // check if determinant is equal to 0
	    else if (determinant == 0) {

	      // two real and equal roots
	      // determinant is equal to 0
	      // so -b + 0 == -b
	      root1 = root2 = -b / (2 * a);
          System.out.println("The Answer is ");
	      System.out.format("root1 = root2 = %.2f;", root1);
	    }

	    // if determinant is less than zero
	    else {

	      // roots are complex number and distinct
	      double real = -b / (2 * a);
	      double imaginary = Math.sqrt(-determinant) / (2 * a);
          System.out.println("The Answer is ");
	      System.out.format("root1 = %.2f+%.2fi", real, imaginary);
	      System.out.format("\nroot2 = %.2f-%.2fi", real, imaginary);
	    }
	  }
	}

