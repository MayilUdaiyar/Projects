package Application_Mayil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserLogin  {
	Scanner input = new Scanner(System.in);

	 private static final String INSERT_new_users_SQL = "INSERT INTO NEW_USERS" +
		        "  (email,password,rating) VALUES " +
		        " (?,?,?);";
public void UserLogin(){
	System.out.println("Here we are Surveying ");
	System.out.println("NOTE: If you Enter your email and password in the correct format your RATING will be included\nelse the RATING will not be included");
	 System.out.println("ENTER YOU EMAIL ID :");
	 System.out.println("Note:Mail-Id Should Be in this Format name@gmail.com ");
	 String email=input.next();
	 System.out.println("Enter your Password :");
	 System.out.println("Entered Password Should Be 8-16Character");
	 System.out.println("It Must Contain Atleast 1 UppercaseLetter");
	 System.out.println("It Must Contain Atleast 1 SpecialCharacter");
	 System.out.println("It Must Contain Atleast 1 NumericalNumber");
	 String password=input.next();
	 System.out.println("Enter your Rating for our developement,PLEASE GIVE THE RATING OUT OF '10'");
	 int rating = input.nextInt();
	 
	 
	 String exp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\\W)(?!.* ).{8,16}$";
		Pattern patterns = Pattern.compile(exp);  
		String regex = "^[A-Za-z0-9+_.-]+@(.+)$";  
		Pattern pattern = Pattern.compile(regex);  
		Matcher matcher = pattern.matcher(email); 
        Matcher matchers=patterns.matcher(password);
        
        if(    matcher.matches()==true) {
        		if(matchers.matches()==true ) {
        	 try (Connection connection = DriverManager
				        .getConnection("jdbc:mysql://localhost:3306/new_customer_login?", "root", "infotel");

				        // Step 2:Create a statement using connection object
				       
        			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_new_users_SQL)) {
    		      preparedStatement.setString(1, email);
      		     preparedStatement.setString(2, password);
      		     preparedStatement.setInt(3,rating);

    		      preparedStatement.executeUpdate();    	
    		  	
  			}
  			  catch (SQLException e) {

  			        // print SQL exception information
  			    	 printSQLException(e);
  			  }
  			 finally {
  				 
  			 } 
        	
        	 }}
        else {
       	 System.out.println("Either Password  or  Email-Id is not given in correct format ");
        }
}
public static void printSQLException(SQLException ex) {
    for (Throwable e: ex) {
        if (e instanceof SQLException) {
            // e.printStackTrace(System.err);
            System.err.println("SQLState: " + ((SQLException) e).getSQLState());
            System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
            System.err.println("Message: " + e.getMessage());
            Throwable t = ex.getCause();
            while (t != null) {
                System.out.println("Cause: " + t);
                t = t.getCause();
          
            
            
            }
        }
    }
  
}
}

