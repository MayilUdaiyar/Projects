package AssessmentShapes;
import java.sql.SQLException;
//additionally i have included 3 more shapes
import java.util.Scanner;

//Thread
public class Shapes2<New> extends Thread {

//Generic is  Declared  
	New object;

	Shapes2(New object) {
		this.object = object;
	}

	public New getObject() {
		return this.object;
	}

//Constructor Class	Is Used For Welcome Note	
	Shapes2() {
		System.out.println("*****************************************************************");
		System.out.println("Hi Buddy...");
		System.out.println(" <<< We Welcoming you to Shapes Formulas >>>  ");
		System.out.println("Finding the Area and Circumference  of Shapes!");
		System.out.println("Enter 1 For Circle Shape :");
		System.out.println("Enter 2 For triangle Shape :");
		System.out.println("Enter 3 For Rectangle Shape:");
		System.out.println("*****************************************************************");

	}

// Enum 
	private enum Enum {
		Bye("You have exited ,If you want to continue from the Main menu please run again");

		public String exit;

		private Enum(String label) {
			this.exit = label;
		}

	}

	public static void main(String args[]) throws SQLException {
		
//Inner class
		Shapes.Shape2 inner = new Shapes().new Shape2();

//Shapes obj(object)Creation For Garbage collection		
		Shapes obj = new Shapes();

//Shapes2 obj2(object)Creation For Constructor		
		Shapes2 obj2 = new Shapes2();
//Scanner 
		Scanner scan = new Scanner(System.in);
//While Is Used For Repeating the Process 		
		Learners_Login objectL2= new Learners_Login();
		System.out.println("Enter 1 for login");
         int option =scan.nextInt();
        	 if(option==1) {
     			
     			Learners_Login.searchbypassord();

		
	while (true) {
			// Exception Handling Is Used - System Defined
			try {
				
				
//Generic 
				Shapes2<String> sObj = new Shapes2<String>("Select your option, And ENJOY your Learning");
				System.out.println(sObj.getObject());
				System.out.println("*****************************************************************");
				int option1 = scan.nextInt();

				// For Finding Area And Circumference of Circle
				if (option1 == 1) {
					System.out.println("Bringing you the  option you selected");
//Thread sleep is used here to wait for 1000 milliseconds
					Thread.sleep(1000);
//After 1000 milliseconds have elapsed, control returns 
					System.out.println(" Here i have 2 more options for you  ");
					System.out.println(" Press 1 for for Area of Circle and  Circumference of the Circle");
					System.out.println(" Press 2 for for Area of Circle and  Circumference of the Cylinder");

					int answer = scan.nextInt();
					if (answer == 1) {
						System.out.println(
								"Enter Radius To Find Area And Circumference of Circle[Entered Radius Should Be An Integer Value]");
						int radius = scan.nextInt();
						Shapes2<Integer> iobj = new Shapes2<Integer>(radius);
						System.out.println(iobj.getObject());
						// inner.getRadius(radius);
						// inner.setRadius(radius);
						System.out.println("Calculating Your Results For Area of Circle...........");
						Thread.sleep(1000);
						inner.area(radius);
						System.out.println("Calculating Your Results For Circumference of Circle...........");
						Thread.sleep(1000);
						inner.circumference(radius);
//Garbage Collection Is Used Here
						obj = null;
						System.gc();
						int getoption = scan.nextInt();
						System.out.println("You will be exited in a second ,Thank you... ");
						System.out.println("Have a GREAT Day!!!!...........");
						Thread.sleep(1000);
						if (getoption == 1) {
//Enum Is Used Here For Getting The Exit Note
							System.out.println(Enum.Bye.exit);
							break;
						}
					} else if (answer == 2) {
						System.out.println("You Have Selected Cylinder");
						System.out.println("Enter 1 For Finding Area of Cylinder ");
						System.out.println("Enter any other number For Finding Circumference of Cylinder ");

						// Setting The Length And Width Value
						int optionArea = scan.nextInt();
						if (optionArea == 1) {
							System.out.println("You Have Selected To Find The Area Of cylinder");
							System.out.println("Enter The radius And height");
							double radius1 = scan.nextDouble();
							double height = scan.nextDouble();
							inner.area(radius1, height);

							// Formula To Find The Area of cylinder
						}

						else if (optionArea == 2) {
							System.out.println("You Have Selected To Find The Circumference Of cylinder");
							System.out.println("Enter The radius");
							int getradius = scan.nextInt();
							inner.circumference(getradius);

							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								System.out.println(e);

							}
						}

						else {
							System.out.println(Enum.Bye.exit);
							break;
						}
					}					}

// For Finding Area And Circumference of Triangle
					else if (option1 == 2) {
						System.out.println("Searching Your Choices...........");
						Thread.sleep(1000);
						System.out.println("You Have Selected To Find The Area  and Circumference of Triangle ");
						System.out.println("Do You want To Find The Area  and Circumference of Triangle enter 1");
						System.out.println("Additionally we included the formula for cone ");
						System.out.println("Do You want To Find The Area  and Circumference of CONE enter 2");
						int answer1 = scan.nextInt();
						if (answer1 == 1) {
							System.out.println(
									"Enter Height To Find Area of Triangle[Entered Height Should Be An Float Value]");
							System.out.println(
									"Enter Base To Find Area  of Triangle [Entered Base Should Be An Integer Value]");
							float height = scan.nextFloat();
							int base = scan.nextInt();
							inner.getHeight(height);
							inner.setHeight(height);
							inner.getBase(base);
							inner.setBase(base);
							System.out.println("Calculating Your Results For Area of Triangle...........");
							Thread.sleep(1000);
							inner.area(height, base);
							System.out.println(
									"Enter Side To Find  Circumference  of Triangle [Entered Side Should Be An Float Value]");
							float side = scan.nextFloat();
							inner.getSide(side);
							inner.setSide(side);
							System.out.println("Calculating Your Results For Circumference of Triangle...........");
							Thread.sleep(1000);
							inner.circumference(side, base);
							obj = null;
							System.gc();
							
							int getoption = scan.nextInt();
							if (getoption == 1) {
								System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
								Thread.sleep(1000);
								System.out.println(Enum.Bye.exit);
								break;
							}
						} else if (answer1 == 2) {

							System.out.println("You Have Selected Cone");
							System.out.println("Enter 1 For Finding Area of Cone");
							System.out.println("Enter any other number For Finding Circumference of Cone ");

							int optionArea = scan.nextInt();
							// Setting The Length And Width Value
							if (optionArea == 1) {
								System.out.println("You Have Selected To Find The Area Of Cone");
								System.out.println("Enter The radius And height");
								double radius = scan.nextDouble();
								int length = scan.nextInt();
								inner.area(radius, length);

								// Formula To Find The Area of Rectangle

							}

							if (optionArea == 2) {
								System.out.println("You Have Selected To Find The Circumference Of cone");
								System.out.println("Enter The radius");
								double radius = scan.nextDouble();
								inner.circumference(radius);

								try {
									Thread.sleep(1000);
								} catch (InterruptedException e) {
									System.out.println(e);

								}
							}

						} else {
							System.out.println(Enum.Bye.exit);
							break;
						}
					}

// For Finding Area And Circumference of Rectangle
					else if (option1 == 3) {
						System.out.println("Searching Your Choices...........");
						Thread.sleep(1000);
						System.out.println("You Have Selected To Find The Area  and Circumference of Rectangle ");
						System.out.println(" Here i have 2 more options for you  ");
						System.out.println(" Press 1 for for Area and  Circumference of the Rectangle");
						System.out.println(" Press 2 for for Area  and  Circumference of the Cube");

						int  answer2 = scan.nextInt();
						if (answer2== 1) {
							System.out.println("Enter Length To Find Area And Circumference of Rectangle");
							System.out.println("[Note:Entered Length Should Be An Integer Value]");

							System.out.println("Enter Width To Find Area And Circumference  of Rectangle ");
							System.out.println("[Note:Entered Width Should Be An Integer Value]");
							int length = scan.nextInt();
							int width = scan.nextInt();
							inner.getLength(length);
							inner.setLength(length);
							inner.getWidth(width);
							inner.setWidth(width);
							System.out.println("Calculating Your Results For Area of Rectangle...........");
							Thread.sleep(1000);
							inner.area(length, width);
							System.out.println("Calculating Your Results For Circumference of Rectangle...........");
							Thread.sleep(1000);
							inner.circumference(length, width);
							obj = null;
							System.gc();
							int getoption = scan.nextInt();
							if (getoption == 1) {
								System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
								Thread.sleep(1000);
								System.out.println(Enum.Bye.exit);
								break;
							}
						}
						else if(answer2== 2) {
						System.out.println("You Have Selected Cube");
						System.out.println("Enter 1 For Finding Area of Cube ");
						System.out.println(" Enter any other number For Finding Circumference of Cube ");
						double optionArea = scan.nextDouble();
						// Setting The side Value
						if (optionArea == 1) {
							System.out.println("You Have Selected To Find The Area Of Cube");
							System.out.println("Enter The Side");

						float side = scan.nextFloat();
							inner.area(side);
							// Formula To Find The Area of Rectangle

							

	                             
						}

						else if (optionArea==2){
							System.out.println("You Have Selected To Find The Circumference Of cube");
							System.out.println("Enter The radius");

							double side = scan.nextDouble();
							inner.circumference(side);
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								System.out.println(e);

							}
		
						}else {
							System.out.println(Enum.Bye.exit);
							break;
						}
					}

					// For Exit Option
					if (option1>3) {
						System.out.println("You'll Be Exited In A Minute Have A Nice Day!!!!...........");
						Thread.sleep(1000);
						System.out.println(Enum.Bye.exit);
						// System.out.println("You Have Selected To Exit");
						// System.out.println("If You Want To Continue The Process ,Run The Program
						// Again ");
						break;
					}
				
			}}

			catch (Exception e) {
				if (e == e) {
				
					System.out.println("Invalid Input , Please enter the valid Input  ");
					break;
				}

			}

			/*
			 * finally { System.out.println("Thankyou !!!!!"); }
			 */
		}
		
	}
         else {
				System.out.println("Invalid username or password. Please try again.");
			}}
}
