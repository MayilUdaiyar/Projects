package AssessmentShapes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Learners_Login  {
	//private static final String QUERY = "select email,password from learner_db where  email=? And password =? ";
	static Scanner input = new Scanner(System.in);

	 private static final String INSERT_learner_db_SQL = "INSERT INTO learner_db" +
		        "  (email,password) VALUES " +
		        " (?,?);"	         ;
	public static void searchbypassord() throws SQLException {

		 System.out.println("Enter The Email");
		
		 String email =input.next();
		 System.out.println("Enter The Password");
			
		 String password =input.next(); 
		 String exp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\\W)(?!.* ).{8,16}$";
			Pattern patterns = Pattern.compile(exp);  
			String regex = "^[A-Za-z0-9+_.-]+@(.+)$";  
			Pattern pattern = Pattern.compile(regex);  
	       
	         Matcher matcher = pattern.matcher(email); 
	         Matcher matchers=patterns.matcher(password);
	         if(    matcher.matches()==true && matchers.matches()==true ) {
	               try (Connection connections = DriverManager
	       				.getConnection("jdbc:mysql://localhost:3306/learner_login?", "root", "infotel");
	       			 PreparedStatement preparedStatements = connections.prepareStatement(INSERT_learner_db_SQL)) {
	       			preparedStatements.setString(1, email);
	       		 preparedStatements.setString(2, password);
	       		 preparedStatements.executeUpdate();
	       		connections.close();
	            //}
	        } catch (SQLException e) {
	            printtheSQLException(e);
	        }
	         }else{
	        	 System.out.println("either the mail id or password is entered incorrect format");
	         }}
		
	        // Step 4: try-with-resource statement will auto close the connection.
	//}
	
	  public static void printtheSQLException(SQLException ex) {
	        for (Throwable e: ex) {
	            if (e instanceof SQLException) {
	                e.printStackTrace(System.err);
	                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
	                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
	                System.err.println("Message: " + e.getMessage());
	                System.out.println("Entered Password Does Not Match");
	                Throwable t = ex.getCause();
	                while (t != null) {
	                    System.out.println("Cause: " + t);
	                    t = t.getCause();
	                }
	            }
	        }
}
}